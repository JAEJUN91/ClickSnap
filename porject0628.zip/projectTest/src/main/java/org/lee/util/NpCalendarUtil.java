package org.lee.util;

public class NpCalendarUtil {
	
	public String[] getDayName() {
		String[] dayNames = {"일","월","화","수","목","금","토"};
		return dayNames;
	}
}
