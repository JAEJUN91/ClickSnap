package org.lee.domain;


// 스케쥴 관리 DTO :이재준
import lombok.Data;

@Data
public class NpCalendarDTO {
	
	private int resNo;
	private String resTitle;
	private String resDate;
	private String resTime;
	private int resPrice;
	private String resLocation;
	private String penalty;
	
	
}
