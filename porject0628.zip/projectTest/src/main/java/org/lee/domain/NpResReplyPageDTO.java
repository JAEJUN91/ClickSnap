package org.lee.domain;
// 예약 게시판 댓글 페이징 처리 DTO : 이재준
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;

@Data
@AllArgsConstructor
@Getter
public class NpResReplyPageDTO {
	private int replyCnt;
	private List<NpResReplyVO> list;
	
} 
