package org.lee.domain;

import java.util.Date;

import lombok.Data;

@Data
public class NpPurchaseDTO {
	private long sno;
	private String title;
	private String cust_id;
	private String cust_name;
	private String artist_id;
	private String status;
	private String phoneNum;
	private Date sDate;
	private String serviceTime;
	private String location;
	private long price;
	private long penalty;
	

}
