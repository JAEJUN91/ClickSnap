package org.lee.domain;

import org.springframework.web.util.UriComponentsBuilder;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class NpCriteria {
	
	private int pageNum; //페이지 번호
	private int amount; // 한 페이지에 출력되는 데이터 수
	private String type; // 검색 항목
	private String keyword; // 검색 키워드
	
	
	
	public NpCriteria() {
		// TODO Auto-generated constructor stub
		this(1,10);
	}

	public NpCriteria(int pageNum, int amount) {
		// TODO Auto-generated constructor stub
		this.pageNum = pageNum; 
		this.amount = amount;
	}
	
	public String[] getTypeArr() {
		return type ==null? new String[] {} : type.split(""); // 검색 조건을 배열로 처리 
		// 이런 필드가 있는 상태에서 만든것 같은 getter 메소드는 mybatis 처리 상에서 Criteria 클래스 안에 typeArr 이라는 필드를 가진것 처럼 처리해준다.
	}
	public String getListLink() {
		UriComponentsBuilder builder = UriComponentsBuilder.fromPath("")
				.queryParam("pageNum", this.getPageNum())
				.queryParam("amount", this.getAmount())
				.queryParam("type", this.getType())
				.queryParam("keyword", this.getKeyword());
				
				
		return builder.toUriString();
	}
}
