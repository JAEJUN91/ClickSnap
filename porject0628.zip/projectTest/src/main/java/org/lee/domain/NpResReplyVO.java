package org.lee.domain;
// 예약 게시판 댓글 VO : 이재준
import java.util.Date;

import lombok.Data;

@Data
public class NpResReplyVO {
	private Long resRno;
	
	private String reply;
	private String replyer;
	private Date replyDate;
	private Date updateDate;
	private Long resBno;
}
