package org.lee.domain;

import lombok.Data;

@Data
public class ServiceTagVO {
	
	private String tag;
	private int sno;
	
}
