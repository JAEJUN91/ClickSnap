package org.lee.domain;
// 예약 게시판 이미지 VO : 이재준
import lombok.Data;

@Data
public class NpResBoardImageVO {
	private String uuid;
	private String uploadPath;
	private String fileName;
	private Long resBno;
}
