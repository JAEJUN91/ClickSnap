package org.lee.domain;
//예약 게시판 VO : 이재준
import java.util.Date;
import java.util.List;



import lombok.Data;

@Data
public class NpResBoardVO {
	private Long resBno;
	private String title;
	private String content;
	private Date regDate;
	private Date updateDate;
	private String status;
	private String writer;
	
	 private int replyCnt; 
	
	private List<NpResBoardImageVO> attachList; // 여러개의 첨부 파일을 가질 수 있도록 수정

}
