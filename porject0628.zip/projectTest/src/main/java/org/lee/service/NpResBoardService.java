package org.lee.service;

//예약 게시판 서비스 : 이재준
import java.util.List;

import org.lee.domain.NpCriteria;
import org.lee.domain.NpResBoardImageVO;
import org.lee.domain.NpResBoardVO;

public interface NpResBoardService {
	public void register(NpResBoardVO resVO);  // 게시물 등록
	public NpResBoardVO get(Long resBno); // 게시물 번호에 따른 게시물 내용
	public boolean modify(NpResBoardVO resVO); // 게시물 수정
	public boolean remove(Long resBno); // 게시물 제거
 	public List<NpResBoardVO> getList(); // 게시물 리스트 
	
	public List<NpResBoardVO> getList(NpCriteria cri); // 페이징 처리된 게시물 수
	public int getTotal(NpCriteria cri); // 게시물의 총 갯수
	
	
	public List<NpResBoardImageVO> getAttachList(Long resBno);
	
}
