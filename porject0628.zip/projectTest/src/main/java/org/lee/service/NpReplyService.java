
package org.lee.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.lee.domain.NpCriteria;
import org.lee.domain.NpResReplyPageDTO;
import org.lee.domain.NpResReplyVO;

//예약 게시판 Reply Service : 이재준
public interface NpReplyService {
	
	public int register(NpResReplyVO resVO);
	public NpResReplyVO get(Long resRno);
	public int modify(NpResReplyVO resVO);
	public int remove(Long resRno);
	public List<NpResReplyVO> getList(@Param("cri")NpCriteria cri, @Param("resBno")Long resBno);
	public NpResReplyPageDTO getListPage(@Param("cri")NpCriteria cri, @Param("resBno")Long resBno);

}
