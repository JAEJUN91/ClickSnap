package org.lee.service;

import java.util.List;

import org.lee.domain.NpCriteria;
import org.lee.domain.NpResReplyPageDTO;
import org.lee.domain.NpResReplyVO;
import org.lee.mapper.NpResBoardMapper;
import org.lee.mapper.NpResReplyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

//예약 게시판 댓글 service impl : 이재준
@Log4j
@Service
@AllArgsConstructor
public class NpReplyServiceImpl implements NpReplyService{
	@Setter(onMethod_ = @Autowired)
	private NpResReplyMapper resReplyMapper;
	@Setter(onMethod_ = @Autowired)
	private NpResBoardMapper resBoardMapper;
	
	@Transactional
	@Override
	public int register(NpResReplyVO resVO) {
		log.info("register ....:)"+resVO);
		//resBoardMapper.updateReplyCnt(vo.getResBno(), 1);
		return resReplyMapper.insertSelectKey(resVO);
	}

	@Override
	public NpResReplyVO get(Long resRno) {
		log.info("get ....:)"+ resRno);
		return resReplyMapper.read(resRno);
	}

	@Override
	public int modify(NpResReplyVO resVO) {
		log.info("modify ....:)" +resVO);
		return resReplyMapper.update(resVO);
	}
	
	@Transactional
	@Override
	public int remove(Long resRno) {
		log.info("remove ....:)"+ resRno);
		//NpResReplyVO vo = resReplyMapper.read(resRno);
		//resBoardMapper.updateReplyCnt(vo.getResBno(), -1);
		return resReplyMapper.delete(resRno);
	}

	@Override
	public List<NpResReplyVO> getList(NpCriteria cri, Long resBno) {
		log.info("get Reply List Of a Board ....:)"+ resBno);
		return resReplyMapper.getListWithPaging(cri, resBno);
	}
	
	@Override
	public NpResReplyPageDTO getListPage(NpCriteria cri, Long resBno) {
		log.info(resBno+"의 댓글 count 갯수 : "+ resReplyMapper.getListWithPaging(cri, resBno));
		return new NpResReplyPageDTO(resReplyMapper.getCountByBno(resBno), resReplyMapper.getListWithPaging(cri, resBno));
	}
}
