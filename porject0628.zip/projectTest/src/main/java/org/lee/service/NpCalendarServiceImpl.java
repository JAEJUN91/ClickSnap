package org.lee.service;

// 스케쥴 관리 서비스 임플 :  이재준
import java.util.List;

import org.lee.domain.NpCalendarDTO;
import org.lee.mapper.NpCalendarMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;


@Log4j
@Service
@AllArgsConstructor
public class NpCalendarServiceImpl implements NpCalendarService {
	@Setter(onMethod_ = {@Autowired})
	private NpCalendarMapper calMapper;
	
	
	@Override
	public List<NpCalendarDTO> getCalList() {
		log.info("get Calendar List " );
		return calMapper.getCalList();
	}

	

	@Override
	public NpCalendarDTO readCal(int resNo) {
		log.info("read Calendar by resNo");
		return calMapper.readCal(resNo);
	}

}
