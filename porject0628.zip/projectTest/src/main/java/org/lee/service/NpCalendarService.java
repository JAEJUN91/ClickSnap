package org.lee.service;

// 스케쥴관리 서비스 : 이재준
import java.util.List;

import org.lee.domain.NpCalendarDTO;


public interface NpCalendarService {
	public List<NpCalendarDTO> getCalList();
	
	public NpCalendarDTO readCal(int resNo);
}
