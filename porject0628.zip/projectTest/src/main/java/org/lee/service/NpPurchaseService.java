package org.lee.service;

import java.util.List;

import org.lee.domain.NpPurchaseDTO;

public interface NpPurchaseService {
	
	public List<NpPurchaseDTO> getCalList();
	public NpPurchaseDTO getCal(long sno);
}
