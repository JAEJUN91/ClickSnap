package org.lee.service;


import java.util.List;

import org.lee.domain.NpPurchaseDTO;
import org.lee.mapper.NpPurchaseMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class NpPurchaseServiceImpl implements NpPurchaseService{
	@Setter(onMethod_ = {@Autowired})
	NpPurchaseMapper npMapper;

	
	  @Override public NpPurchaseDTO getCal(long sno) { 
		  log.info("get....."); 
		  return  npMapper.read(sno); 
	  }
	

	@Override
	public List<NpPurchaseDTO> getCalList() {
		// TODO Auto-generated method stub
		return npMapper.getPurchaseList(0);
	}

}
