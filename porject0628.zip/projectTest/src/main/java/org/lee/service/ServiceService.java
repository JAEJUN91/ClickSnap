package org.lee.service;

import org.lee.domain.ServiceVO;

public interface ServiceService {

	public void insert(ServiceVO vo);
}
