package org.lee.service;
//예약 게시판 서비스 임플 : 이재준

import java.util.List;

import org.lee.domain.NpCriteria;
import org.lee.domain.NpResBoardImageVO;
import org.lee.domain.NpResBoardVO;
import org.lee.mapper.NpResBoardImageMapper;
import org.lee.mapper.NpResBoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class NpResBoardServiceImpl implements NpResBoardService {
	@Setter(onMethod_ = {@Autowired})
	private NpResBoardMapper resMapper;
	@Setter(onMethod_ = {@Autowired})
	private NpResBoardImageMapper resImgMapper;	
	
	@Override
	public void register(NpResBoardVO resVO) {
		log.info("register....:)"+ resVO.getResBno());
		
		resMapper.insertSelectKey(resVO);
		
		if(resVO.getAttachList()==null||resVO.getAttachList().size()<=0) {
			return;
		}

		resVO.getAttachList().forEach(attach->{
			attach.setResBno(resVO.getResBno());
			resImgMapper.insert(attach);

		});
		
	}

	@Override
	public NpResBoardVO get(Long resBno) {
		log.info("예약 게시판 번호에 따른 출력");
		return resMapper.read(resBno);
	}

	@Override
	public boolean modify(NpResBoardVO resVO) {
		log.info("예약 게시판 게시물 수정 "+ resVO);
		resImgMapper.deleteAll(resVO.getResBno()); //db에서 모든 첨부파일 정보 삭제
		boolean modifyResult = resMapper.update(resVO)==1; //board 테이블 정보 수정
		if(modifyResult && resVO.getAttachList()!=null&& resVO.getAttachList().size()>0) {
			resVO.getAttachList().forEach(attach->{
				attach.setResBno(resVO.getResBno());
				resImgMapper.insert(attach);
			});
		}
		return modifyResult;
	}

	@Override
	public boolean remove(Long resBno) {
		log.info("예약게시판 게시물 제거"+ resBno);
		resImgMapper.deleteAll(resBno);
		return resMapper.delete(resBno)==1;
	}

	@Override
	public List<NpResBoardVO> getList() {
		log.info("예약 페이지 리스트 " );
		return resMapper.getList();
	}

	@Override
	public List<NpResBoardVO> getList(NpCriteria cri) {
		log.info("getList with criteria" +cri);
		return resMapper.getListWithPaging(cri);
	}

	@Override
	public int getTotal(NpCriteria cri) {
		log.info("게시물 총 갯수 " + cri);
		return resMapper.getTotalCount(cri);
	}

	@Override
	public List<NpResBoardImageVO> getAttachList(Long resBno) {
		log.info("게시물 번호에 따른 게시물 리스트"+ resBno);
		return resImgMapper.findByResBno(resBno);
	}

}
