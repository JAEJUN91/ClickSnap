package org.lee.controller;
// 예약 게시판 controller : 이재준
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;


import org.lee.domain.NpCriteria;
import org.lee.domain.NpPageDTO;
import org.lee.domain.NpResBoardImageVO;
import org.lee.domain.NpResBoardVO;
import org.lee.service.NpResBoardService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/resBoard/*")
@AllArgsConstructor
public class NpResBoardController {
	private NpResBoardService resService;
	
	@GetMapping("/resList")    // 게시판 리스트 출력
		public void getList(Model model, NpCriteria cri) {
		log.info("npReservBoard List");
		model.addAttribute("list",resService.getList(cri));
		
		 int total = resService.getTotal(cri);
		 log.info("getTotal : "+ total);
		 model.addAttribute("pageMaker", new NpPageDTO(cri, total));
		
	}
	@GetMapping(value="/getAttachList", produces=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<List<NpResBoardImageVO>> getAttachList(Long resBno){
		log.info("get 어태치 리스트 : " + resBno);
		return new ResponseEntity<>(resService.getAttachList(resBno),HttpStatus.OK);
	}
	
	
	  @GetMapping("/register") 
	  public void register() {
	  
	  }
	 
	
	@PostMapping("/register")
	public String register(NpResBoardVO resBoard, RedirectAttributes rttr) {
		log.info("예약 게시판 게시물 등록");
		   System.out.print("게시물 등록 리스트"+resBoard.toString());
		if(resBoard.getAttachList()!=null) {
			resBoard.getAttachList().forEach(attach-> log.info(attach));		
		}
		resService.register(resBoard);
		rttr.addFlashAttribute("resResult" + resBoard.getResBno());
		
		return "redirect:/resBoard/resList";
		
	}
	
	@GetMapping({"/get","/modify"}) // 해당 글 가져오는 방식
	public void get(@RequestParam("resBno")Long resBno,@ModelAttribute("cri") NpCriteria cri, Model model) {
		log.info("/get or /modify");
		model.addAttribute("resBoard", resService.get(resBno));
	}
	
	@PostMapping("/modify") // post방식 게시글 수정
	public String get(NpResBoardVO resVO, @ModelAttribute("cri")NpCriteria cri, RedirectAttributes rttr) {
		log.info("modify" + resVO);
		if(resService.modify(resVO)) {
			rttr.addFlashAttribute("result","success");
		}

		return "redirect:/resBoard/resList"+ cri.getListLink();
	}
	@PostMapping("/remove")
	public String remove(@RequestParam("resBno")Long resBno, @ModelAttribute("cri")NpCriteria cri, RedirectAttributes rttr, String writer) {
		log.info("remove........:)"+resBno);
		List<NpResBoardImageVO> attachList = resService.getAttachList(resBno);
		if(resService.remove(resBno)){
			deleteFiles(attachList); // 서버 폴더 내의 파일 삭제
			rttr.addFlashAttribute("result","success"); // 한번만 저장되도록 하는 태그s
		}
//		rttr.addAttribute("pageNum",cri.getPageNum());
//		rttr.addAttribute("amount",cri.getAmount());
//		rttr.addAttribute("keyword",cri.getKeyword());
//		rttr.addAttribute("type",cri.getType());
		return "redirect:/resBoard/resList"+ cri.getListLink();
	}
	
	
	private void deleteFiles(List<NpResBoardImageVO> attachList) {
		if(attachList==null || attachList.size()==0) {
			
			
			return; 
		}
		
		log.info("delete attach files");
		log.info(attachList);
		attachList.forEach(attach->{
			
			try {
				Path file= Paths.get("c:/resImgs/"+ attach.getUploadPath()+"/" + attach.getUuid()+"_"+attach.getFileName());
				Files.deleteIfExists(file);
				if(Files.probeContentType(file).startsWith("image")) {
					Path thumbNail = Paths.get("c:/resImgs/"+attach.getUploadPath()+"/s_"+ attach.getUuid()+ "_"+attach.getFileName());
					Files.delete(thumbNail);
				}
			} catch (IOException e) {
				log.error("delete file error"+e.getMessage());
			}
		});
		//forEach 끝
	}
	// deleteFiles 끝
}
// NpResBoardController 끝