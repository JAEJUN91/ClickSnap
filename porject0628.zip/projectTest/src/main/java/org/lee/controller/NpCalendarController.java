package org.lee.controller;
// 스케쥴 관리 controller : 이재준
import java.util.ArrayList;
import java.util.List;

import org.lee.domain.NpCalendarDTO;
import org.lee.service.NpCalendarService;
import org.lee.service.NpResBoardService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;



@Controller
@Log4j
@RequestMapping("/artPage/*")
@AllArgsConstructor
public class NpCalendarController {
	private NpCalendarService npService;
	
	@GetMapping("/calMain")
	public void calMain() {
		log.info("스케쥴 관리 달력");
	}
	    
	/*@PostMapping(value ="/NpPurchaseListAction", produces=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<List<NpReserveCalendarDTO>> getCalMainPost(@RequestParam("sno")int sno, Model model) {
        List<NpReserveCalendarDTO> calList = new ArrayList<NpReserveCalendarDTO>();
        log.info("CalendarController calMain()");
        
        model.addAttribute("list",purMapper.getPurchaseList(sno)); 
        model.addAttribute("cal", new NpCalendarUtil());
        
        return new ResponseEntity<>(calList, HttpStatus.OK );
    }*/
	

	
	  @PostMapping(value="/NpCalendarAction", produces =  MediaType.APPLICATION_JSON_VALUE, consumes= MediaType.APPLICATION_JSON_VALUE)
	  @ResponseBody public ResponseEntity<List<NpCalendarDTO>> getCalMainPost(){
		 System.out.println("1"); 
		 List<NpCalendarDTO> list = npService.getCalList(); 
		 log.info("npList" +list);
	  
	  	
		 return new ResponseEntity<>(list, HttpStatus.OK);
	  
	  }
	 
	
	
	@GetMapping("/index")
	public void index() {
		log.info("log");
	}
	
}
