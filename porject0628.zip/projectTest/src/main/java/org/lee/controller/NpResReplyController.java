package org.lee.controller;
// 예약 게시판 댓글 controller : 이재준
import org.lee.domain.NpCriteria;
import org.lee.domain.NpResReplyPageDTO;
import org.lee.domain.NpResReplyVO;
import org.lee.service.NpReplyService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;



@RequestMapping("/replies")
@RestController
@Log4j
@AllArgsConstructor
public class NpResReplyController {
	private NpReplyService service;
	
	
	@PostMapping(value="/new", consumes="application/json", produces={MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> create(@RequestBody NpResReplyVO resVO){
		log.info("resReplyVO : "+resVO);
		int insertCount = service.register(resVO);
		log.info("Reply INSERT COUNT : " + insertCount);
		
	return insertCount ==1 ? new ResponseEntity<>("success", HttpStatus.OK) : new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@GetMapping(value="/pages/{resBno}/{page}", produces= {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<NpResReplyPageDTO> getList(@PathVariable("page")int page, @PathVariable("resBno")Long resBno){
		log.info("getList.........:)");
		NpCriteria cri = new NpCriteria(page,10);
		log.info("get Reply List resbno");
		log.info("cri : "+cri);
		
		return new ResponseEntity<>(service.getListPage(cri, resBno), HttpStatus.OK);
	}
	
	@GetMapping(value="/{resRno}", produces= {MediaType.APPLICATION_ATOM_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<NpResReplyVO> get(@PathVariable("resRno")Long resRno){
		log.info("get Reply : " + resRno);
		return new ResponseEntity<>(service.get(resRno), HttpStatus.OK);
		
	}

	@DeleteMapping(value="/{resRno}", produces= {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> remove(@PathVariable("resRno")Long resRno){
		log.info("remove Reply : " +resRno);
		return service.remove(resRno)==1 ? new ResponseEntity<>("success", HttpStatus.OK) : new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@RequestMapping(method= {RequestMethod.POST}, value="/{resRno}/reply/{reply}" ,consumes="application/json",
				produces= {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> modify(@RequestBody NpResReplyVO resVO){
	
		
		log.info("modify Reply : " + resVO);
		return service.modify(resVO)==1 ? new ResponseEntity<>("success", HttpStatus.OK): new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
}
