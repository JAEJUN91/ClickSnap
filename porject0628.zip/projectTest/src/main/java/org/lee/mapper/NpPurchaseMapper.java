package org.lee.mapper;

import java.util.List;

import org.lee.domain.NpPurchaseDTO;

public interface NpPurchaseMapper {
	public List<NpPurchaseDTO> getPurchaseList(long sno);
	public NpPurchaseDTO read(long sno);
	
}
