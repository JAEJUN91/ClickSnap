package org.lee.mapper;
//예약 게시판 mapper : 이재준
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.lee.domain.NpCriteria;
import org.lee.domain.NpResBoardVO;

public interface NpResBoardMapper {
	public List<NpResBoardVO> getList();// 게시판 전체의 리스트를 가져오는 메소드
	
	public void insert(NpResBoardVO resVO); // create 게시판에 삽입하는 resboardvo 한개씩 기본키가 필요하지 않는 경우
	public void insertSelectKey(NpResBoardVO resVO); // 기본키가 필요한 경우
	
	public NpResBoardVO read(Long resBno); // resBoardVO에 있는 bno 읽어오는 메소드
	public int delete(Long resBno); // 삭제하는 메소드
	public int update(NpResBoardVO resVO); // 게시판 업데이트하는 메소드
	public List<NpResBoardVO> getListWithPaging(NpCriteria cri); // 페이징 처리된 리스트 불러오는 메소드
	public int getTotalCount(NpCriteria cri); // 데이터베이스에 들어있는 게시물의 총 갯수
	public void updateReplyCnt(@Param("resBno")Long resBno, @Param("amount")int amount); // 댓글 총 갯수
}
