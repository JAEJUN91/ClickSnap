package org.lee.mapper;
// 예약 게시판 댓글 mapper : 이재준
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.lee.domain.NpCriteria;
import org.lee.domain.NpResReplyVO;



public interface NpResReplyMapper {

	public int insertSelectKey(NpResReplyVO resVO); // 댓글 추가하는 메소드
	public NpResReplyVO read(Long resRno);
	public int delete(Long resRno);
	public int update(NpResReplyVO resVO);
	public List<NpResReplyVO> getListWithPaging(@Param("cri")NpCriteria cri, @Param("resBno")Long resBno); // 댓글 목록과 페이징 처리 
	public int getCountByBno(Long resBno);			 // 특정한 게시물의 댓글만을 대상으로 하기 떄문에 게시글 번호 필요
														 // MyBatis의 패러미터는 1개만 허용 2개 이상 전달하기 위한 방법 
															 // map형태, 별도의 클래스사용, @Param이용 #{}사용 가능
	
	
}
