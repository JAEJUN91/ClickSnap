package org.lee.mapper;
//예약 게시판 이미지 : 이재준
import java.util.List;

import org.lee.domain.NpResBoardImageVO;



public interface NpResBoardImageMapper {
	public void insert(NpResBoardImageVO resVO);
	public void delete(String uuid);
	public List<NpResBoardImageVO> findByResBno(Long resBno);
	
	public void deleteAll(Long resBno);
	public List<NpResBoardImageVO> getOldFile();
}
