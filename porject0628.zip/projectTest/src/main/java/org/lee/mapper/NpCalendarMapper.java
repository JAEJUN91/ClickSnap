package org.lee.mapper;
//스케쥴 관리 mapper : 이재준
import java.util.List;

import org.lee.domain.NpCalendarDTO;

public interface NpCalendarMapper {
	public List<NpCalendarDTO> getCalList();
	public NpCalendarDTO readCal(int schedule_code);
}
