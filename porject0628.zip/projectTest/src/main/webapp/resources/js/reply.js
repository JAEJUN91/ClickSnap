

//console.log("Reply Module.........:)");
//var replyService=(function(){
	
//	return {name:"AAA"}; 
//})(); //replyService라는 변수에 name이라는 속성, 'AAA'라는 값을 가진 객체 할당



var replyService =(function(){ // 모튤 패턴: 즉시 실행하는 함수 내부에 메소드를 구성해서 객체로 반환
	function add(reply, callback, error){ // Ajax처리 후 동작해야하는 함수
		console.log("reply...");
		$.ajax({						// Ajax로 ReplyController 호출
			type:'post',
			url:'/replies/new',
			data: JSON.stringify(reply),
			contentType:"application/json; charset=utf-8",
			success: function(result,status,xhr){
				if(callback){
					callback(result);
				}	
			},
			error: function(xhr,status,er){
				if(error){
					error(er);
				}
			}
		})
		//end ajax
	}
	// end add
	function getList(param,callback,error){
		var resBno = param.resBno;
		var page= param.page||1;  
		$.getJSON("/replies/pages/"+resBno+"/"+page+".json", 
		function(data){
			if(callback){
				//callback(data); // 댓글 목록만 가져오는 경우
				callback(data.replyCnt, data.list); // 댓글 숫자와 목록을 가져오는 경우
			}
		}).fail(function(xhr,status,err){
			if(error){
				error();
			}
		});
		//end getJSON
	}
	//end getList
	function remove(resRno,callback,error){
		$.ajax({
			type:'delete',
			url:'/replies/'+resRno,
			
			
			success:function(deleteResult, status, xhr){
				if(callback){
					callback(deleteResult);
				}
			},
			error:function(xhr,status,er){
				if(error){
					error(er);
				}
			}
		});
	}
	//end remove
	
	function update(reply, callback, error){
		$.ajax({
			type:'POSt',
			url:'/replies/'+reply.resRno+'/reply/'+reply.reply,
			data: JSON.stringify(reply),
			contentType:"application/json; charset=utf-8",
			success : function(result, status,xhr){
				if(callback){
					callback(result);
				}
			}, error: function(xhr,status,er){
				if(error){
					error(er);
				}
			}
		});
	}
	//end update
	
	function get(resRno,callback,error){
		$.get("/replies/"+resRno+".json",function(result){
			if(callback){
				callback(result);
			}
		}).fail(function(xhr,status,err){
			if(error){
				error();
			}
		});
	}
	//end get
	
	function displayTime(timeValue){
		var today=new Date();
		var gap = today.getTime()-timeValue; // 시간 차
		var dateObj= new Date(timeValue);
		var str="";
		if(gap<(1000*60*60*24)){
			var hh=dateObj.getHours();
			var mi=dateObj.getMinutes();
			var ss=dateObj.getSeconds();
			return [(hh>9?'':'0')+hh, ':',(mi>9?'':'0')+mi, ':', (ss>9?'':'0')+ss].join('');
		}else{
			var yy= dateObj.getFullYear();
			var mm= dateObj.getMonth();
			var dd= dateObj.getDate();
			return [yy,'/', (mm>9? '':'0')+mm, '/', (dd>9? '': '0')+dd].join('');
		}
	}
	//end displayTime
	return{
		add:add,    // 모튤 패턴으로 외부에 노출하는 정보 
		getList : getList,
		remove:remove,
		update:update,
		get:get,
		displayTime:displayTime
		}; 
})();
