package org.np.mapper;

import java.util.List;

import org.np.domain.ServiceVO;

public interface ServiceMapper {
	
	public int insert(ServiceVO vo);
	public List<ServiceVO> getList();
}
