package org.np.domain;

import java.util.List;

import lombok.Data;

@Data
public class ServiceVO {

	private int sno;
	private String content;
	private String category;
	private String[] tList;
	private int serviceTime;
	private String location;
	private String artist_id;
	private String registerDate;
	private List<ServiceImageVO> iList;
	
}
