package org.np.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.np.domain.MemberVO;
import org.np.mapper.MemberMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import lombok.Setter;
import lombok.extern.log4j.Log4j;


@Log4j
public class CustomUserDetailsService implements UserDetailsService {

	
	@Setter(onMethod_ ={@Autowired})
	private MemberMapper memberMapper;
	
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// TODO Auto-generated method stub
		
		MemberVO vo = memberMapper.read(username);
		log.warn("queried by member mapper : " + vo);
		log.info("여기를 타나");
		return vo==null? null:new CustomUser(vo);
	}

}
