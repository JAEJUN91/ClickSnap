package org.np.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ServiceImageVO {

	private String uuid;
	private String uploadPath;
	private String fileName;
	private int sno;
}
