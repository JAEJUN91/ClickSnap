package org.np.domain;

import lombok.Data;

@Data
public class ServiceTagVO {
	
	private String tag;
	private int sno;
	
}
