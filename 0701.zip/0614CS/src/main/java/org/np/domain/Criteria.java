package org.np.domain;

import java.util.List;

import lombok.Data;

@Data
public class Criteria {
	
	private List<ServiceImageVO> iList;
	private List<ServiceTagVO> tList;
	
}
