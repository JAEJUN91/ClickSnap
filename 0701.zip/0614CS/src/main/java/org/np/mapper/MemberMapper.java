package org.np.mapper;

import org.np.domain.MemberVO;

public interface MemberMapper {

	
	 public MemberVO read(String userid);
}
