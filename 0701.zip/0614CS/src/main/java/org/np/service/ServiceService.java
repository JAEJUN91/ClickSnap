package org.np.service;

import org.np.domain.ServiceVO;

public interface ServiceService {

	public void insert(ServiceVO vo);
}
