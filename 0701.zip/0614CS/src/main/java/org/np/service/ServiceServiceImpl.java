package org.np.service;

import org.np.domain.ServiceImageVO;
import org.np.domain.ServiceTagVO;
import org.np.domain.ServiceVO;
import org.np.mapper.ServiceImageMapper;
import org.np.mapper.ServiceMapper;
import org.np.mapper.ServiceTagMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service
@AllArgsConstructor
@Log4j
public class ServiceServiceImpl implements ServiceService {

	@Setter(onMethod_ = {@Autowired})
	private ServiceMapper mapper;
	
	@Setter(onMethod_ = {@Autowired})
	private ServiceImageMapper iMapper;
	
	@Setter(onMethod_ = {@Autowired})
	private ServiceTagMapper tMapper;
	
	@Override
	public void insert(ServiceVO vo) {
		log.info("ServiceServiceImpl 실행");
		mapper.insert(vo);
		ServiceTagVO tVO = new ServiceTagVO();

		for(ServiceImageVO i : vo.getIList()) {
			ServiceImageVO iVO = new ServiceImageVO(i.getUuid(), i.getUploadPath(), i.getFileName(), i.getSno());
			iMapper.insert(iVO);
		}
		
		for(String t:vo.getTList()) {
			tVO.setSno(vo.getSno());
			tVO.setTag(t);
			tMapper.insert(tVO);
		}
		//ServiceMapper, SeriviceImageMapper 둘다 활용
	}
}
