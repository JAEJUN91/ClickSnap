package org.np.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class csController {

	@RequestMapping(value = "/cs", method = RequestMethod.GET)
	public String cs() {
		
		return "cs";
	}
	@RequestMapping(value = "/faq", method = RequestMethod.GET)
	public String cscs() {
		
		return "faq";
	}
	
	
	
}
