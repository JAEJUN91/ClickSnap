package org.np.controller;


import org.junit.Test;

import lombok.extern.log4j.Log4j;

@Log4j
public class TestController {
	@Test
	public void testDelete() {
		 log.info("DELETE COUNT : ");
	 }
} 
