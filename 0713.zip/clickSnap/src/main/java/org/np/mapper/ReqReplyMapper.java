package org.np.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.np.domain.ReqCriteria;
import org.np.domain.ReqReplyVO;

public interface ReqReplyMapper {
	public int insert(ReqReplyVO board);
	public ReqReplyVO read(Long reqRno);
	public int delete(Long reqRno);
	public int update (ReqReplyVO reply);
	public List<ReqReplyVO> getListWithPaging(@Param("cri") ReqCriteria cri, 
			@Param("reqBno") Long reqBno);
	public int getCountByBno(Long reqBno);
}
