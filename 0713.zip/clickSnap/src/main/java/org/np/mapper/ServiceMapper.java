package org.np.mapper;

import java.util.List;

import org.np.domain.Criteria;
import org.np.domain.ServiceDTO;
import org.np.domain.ServiceVO;
import org.springframework.web.bind.annotation.RequestParam;

public interface ServiceMapper {
	
	public int insert(ServiceVO vo);
	public List<ServiceVO> searchList(Criteria cri);
	public List<ServiceVO> searchByCategory(String category);
	public List<ServiceVO> getListById(String artistId);
	public ServiceVO getBySno(int sno);
	public void delete(int sno); 
	public List<ServiceVO> getList();
	public List<ServiceVO> getListWithPaging(Criteria cri);
	public int getTotalCount(Criteria cri);
	public List<ServiceVO> search(@RequestParam("cri")Criteria cri);
	public List<ServiceVO> getRecList();
}
