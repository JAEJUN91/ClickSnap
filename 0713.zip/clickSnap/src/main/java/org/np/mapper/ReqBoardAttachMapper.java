package org.np.mapper;

import java.util.List;

import org.np.domain.ReqBoardAttachVO;

public interface ReqBoardAttachMapper {//첨부파일은 수정이 존재하지 않으니 삽입/삭제만
	public void insert(ReqBoardAttachVO board);
	public void delete(String uuid);
	public void deleteAll(Long reqBno);
	public List<ReqBoardAttachVO> findByBno(Long reqBno); //게시물 번호로 특정 첨부파일을 찾을 수 있겐
	
	public List<ReqBoardAttachVO> getOldFiles(); //어제 날짜로
}
