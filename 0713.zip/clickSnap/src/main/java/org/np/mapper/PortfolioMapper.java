package org.np.mapper;

import org.np.domain.PortfolioVO;

public interface PortfolioMapper {

	public void insert(PortfolioVO vo);
	
}
