package org.np.mapper;

import java.util.List;

import org.np.domain.ArtistVO;

public interface ArtistMapper {

	public ArtistVO read(String artistId);
	public int getCount();
	public List<ArtistVO> getAll();
}
