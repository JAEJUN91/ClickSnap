package org.np.mapper;

import java.util.List;

import org.np.domain.ReqBoardVO;
import org.np.domain.ReqCriteria;

public interface ReqBoardMapper {
	//@Select("select * from tbl_board where bno > 0") <-이런식으로 안할거임
	public List<ReqBoardVO> getList();
	public void insert(ReqBoardVO board);
	public void insertSelectKey(ReqBoardVO board);
	public ReqBoardVO read(Long reqBno);
	public int delete(Long reqBno);
	public int update(ReqBoardVO board);
	public List<ReqBoardVO> getListWithPaging(ReqCriteria cri);
	public int getTotalCount(ReqCriteria cri);
	
	/*
	 * public void updateReplyCnt(@Param("reqBno")Long reqBno, @Param("amount")int
	 * amount);
	 */
}
