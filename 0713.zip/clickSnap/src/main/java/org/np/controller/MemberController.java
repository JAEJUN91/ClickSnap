package org.np.controller;

import java.io.IOException;

import javax.servlet.http.HttpSession;

import org.np.mapper.MemberMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.scribejava.core.model.OAuth2AccessToken;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
public class MemberController {

	/* NaverLoginBO */
    private NaverLoginBO naverLoginBO;
    private String apiResult = null;
    
    @Autowired
    private void setNaverLoginBO(NaverLoginBO naverLoginBO) {
        this.naverLoginBO = naverLoginBO;
    }
	
	
	@Setter(onMethod_ = {@Autowired})
	private MemberMapper mapper;
	
	/*
	 * @GetMapping("/login") public void goToLoginPage() {
	 * log.info("login page濡� �씠�룞!"); }
	 * 
	 * @PostMapping("/login/loginProc") public String loginProc(MemberVO vo) {
	 * log.info("vo : " + vo); return "/index"; }
	 */
	
	@GetMapping("/myPage")
	public void myPage(String userId, Model model) {
		log.info("myPage로 이동합니다.");
		model.addAttribute("member",mapper.read(userId));
	}
	
	 
	}
	

