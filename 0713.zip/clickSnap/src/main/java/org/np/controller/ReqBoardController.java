package org.np.controller;


import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.np.domain.ReqBoardAttachVO;
import org.np.domain.ReqBoardVO;
import org.np.domain.ReqCriteria;
import org.np.domain.ReqPageDTO;
import org.np.service.ReqBoardService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/request/*")
@AllArgsConstructor
public class ReqBoardController {
	private ReqBoardService reqService;

	@GetMapping("/list")
	public void list(ReqCriteria cri, Model model) {
		log.info("list " + cri);
		model.addAttribute("list", reqService.getList(cri));
		int total = reqService.getTotal(cri);
		log.info("total : " + total);
		model.addAttribute("pageMaker", new ReqPageDTO(cri, total));
	}

	/*
	 * @PreAuthorize("isAuthenticated()")
	 */

	@GetMapping("/register")
	public void register() {

	}

	
	@PostMapping("/register") 
	public String register(ReqBoardVO board, RedirectAttributes rttr) {
	System.out.print("res"+board.getAttachList());
		if(board.getAttachList()!=null) {
			board.getAttachList().forEach(attach->log.info(attach));
		}
		reqService.register(board);
		rttr.addFlashAttribute("result", board.getReqBno());
		return "redirect:/request/list";
	  
	}
	 

	@GetMapping({"/get", "/modify"})
	public void get(@RequestParam("reqBno") Long reqBno, @ModelAttribute("cri") ReqCriteria cri, Model model) {
		log.info("get or modify");
		model.addAttribute("board", reqService.get(reqBno));
	}

	@PostMapping("/modify")
	public String modify(ReqBoardVO board, @ModelAttribute("cri") ReqCriteria cri, RedirectAttributes rttr) {
		log.info(" modify");
		if(reqService.modify(board))
			rttr.addFlashAttribute("result", "success");
		
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		
		return "redirect:/request/list";
	}
	
	@PostMapping("/remove")
	public String remove(@RequestParam("reqBno") Long reqBno, @ModelAttribute("cri") ReqCriteria cri, RedirectAttributes rttr) {
		log.info("remove"+reqBno);
		
		List<ReqBoardAttachVO> attachList = reqService.getAttachList(reqBno); 
		
		if(reqService.remove(reqBno))
			rttr.addFlashAttribute("result", "success");
		
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		
		return "redirect:/request/list";
	}
	
	@GetMapping(value = "/getAttachList", produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<List<ReqBoardAttachVO>>getAttachList(Long reqBno){
		log.info("getAttachList" + reqBno);
		return new ResponseEntity<>(reqService.getAttachList(reqBno), HttpStatus.OK);
	}

	private void deleteFiles(List<ReqBoardAttachVO> attachList) {
		if(attachList==null||attachList.size()==0) {return;}
		log.info("delete attach files");
		log.info(attachList);
		attachList.forEach(attach->{
			try {
				Path file = Paths.get("c:/upload/"+attach.getUploadPath()+"/"+attach.getUuid()+"_"+attach.getFileName());
				Files.deleteIfExists(file);
				if(Files.probeContentType(file).startsWith("image")) {
					Path thumbNail = Paths.get("c:/upload/"+attach.getUploadPath()+"/s_"+attach.getUuid()+"_"+attach.getFileName());
					Files.delete(thumbNail);
				}
			}catch(Exception e) {
				log.error("delete file error: "+e.getMessage());
			}
		});//for each
	}
}
