package org.np.controller;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.imageio.ImageIO;

import org.np.domain.ArtistVO;
import org.np.domain.AttachFileDTO;
import org.np.domain.ServiceDTO;
import org.np.domain.ServiceImageVO;
import org.np.domain.ServiceTagVO;
import org.np.domain.ServiceVO;
import org.np.mapper.ArtistMapper;
import org.np.mapper.ServiceImageMapper;
import org.np.mapper.ServiceTagMapper;
import org.np.service.ServiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.log4j.Log4j;
import net.coobird.thumbnailator.Thumbnailator;

@Controller
@Log4j
@RequestMapping("/artPage/*")
public class ArtistController {
	
	@Setter(onMethod_ = {@Autowired})
	private ServiceService service;
	
	@Setter(onMethod_ = {@Autowired})
	private ArtistMapper aMapper;
	
	@Setter(onMethod_ = {@Autowired})
	private ServiceImageMapper iMapper;
	
	@Setter(onMethod_ = {@Autowired})
	private ServiceTagMapper tMapper;
	
	@PostMapping(value="/uploadAjaxAction", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<AttachFileDTO>> uploadFormPost(MultipartFile[] uploadFiles) {
		
		String uploadFolder = "c:/imgs";
		List<AttachFileDTO> list = new ArrayList<>();
		File uploadPath = new File(uploadFolder, getFolder());
		log.info("upload경로 : "+uploadPath);
		
		if(uploadPath.exists()==false) {
			uploadPath.mkdirs();
		}
		log.info(uploadFiles.length);
		
		for(MultipartFile mf : uploadFiles) {
			AttachFileDTO attachDTO = new AttachFileDTO();
			log.info("파일 보여주러 들어감");
			log.info("fileName : "+mf.getOriginalFilename());
			log.info("fileSize : "+mf.getSize());
			
			UUID uuid = UUID.randomUUID();
			String uploadFileName = mf.getOriginalFilename();
			attachDTO.setFileName(uploadFileName);
			uploadFileName = uuid.toString()+"_"+mf.getOriginalFilename();
			File saveFile = new File(uploadPath,uploadFileName);
			
			try {
				mf.transferTo(saveFile);
				attachDTO.setUuid(uuid.toString());
				BufferedImage bi = ImageIO.read(saveFile);
				attachDTO.setUploadPath(getFolder());
				FileOutputStream thumbnail = 
				new FileOutputStream(new File(uploadPath,"s_"+uploadFileName));
				Thumbnailator.createThumbnail(mf.getInputStream(), thumbnail,
						(int)(bi.getWidth()*0.4),(int)(bi.getHeight()*0.4));
				thumbnail.close();
				list.add(attachDTO); log.info("attachDTO : "+attachDTO);
			}catch (Exception e) {
				log.error(e.getMessage());
			}
		}
		return new ResponseEntity<>(list, HttpStatus.OK);
	}
	
	@GetMapping("/display")
	@ResponseBody
	public ResponseEntity<byte[]> getFile(String fileName){
		log.info("이미지 이름 : "+ fileName);
		File file = new File("c:/imgs/"+fileName);
		ResponseEntity<byte[]> result = null;
		try {
			log.info("이미지 보여준다.");
			HttpHeaders header = new HttpHeaders();
			header.add("Content-Type", Files.probeContentType(file.toPath()));
			result = new ResponseEntity<>(FileCopyUtils.copyToByteArray(file),
					header, HttpStatus.OK);	
		}catch (Exception e) {e.printStackTrace();}
		return result;
	}

	@PostMapping("/register")
	public String register(ServiceVO vo, RedirectAttributes rttr) {
		log.info("register : "+ vo);
		for(int i=0; i<vo.getTList().length; i++) {
			log.info(vo.getTList()[i]);
		}
		vo.getIList().forEach(imgs -> log.info("images : "+imgs));
		service.insert(vo);
		rttr.addFlashAttribute("result", vo.getSno());
		return "redirect:/artPage/artistList?artistId="+vo.getArtist_id();
	}
	
	public String getFolder() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String str = sdf.format(date);
		//str = 2021-06-06
		return str.replace("-", File.separator);
	}
	

	// �긽�뭹 �벑濡앺븯�뒗 遺�遺�
	@GetMapping("/register")
	public void register(String artistId, Model model) {
		log.info("등록 페이지로 이동!");
		model.addAttribute("artistId",artistId);
	}
	
	/*@PostMapping("/register") // post諛⑹떇 寃뚯떆湲� ���옣
	public String register(NpProductVO npvo, RedirectAttributes rttr) {
		log.info("register :" + npvo);
		if(npvo.getImageList()!=null) {
			npvo.getImageList().forEach(attach-> log.info(attach));		
		}
		log.info("================================");
		npservice.register(npvo);
		rttr.addFlashAttribute("result" , npvo.getSno());
		return "redirect:/artPage/list";  // redirect瑜� �븯吏� �븡�뒗 寃쎌슦�뒗, �깉濡쒓퀬移⑥떆 �룄諛곌� �맂�떎.
	}*/
	
	@GetMapping("/map")
	public void test() {
		log.info("123123");
	}
	// \. �긽�뭹 �벑濡앺븯�뒗 遺�遺� �걹
	
	@GetMapping("/artistList")
	public void artistList(String artistId, Model model) {
		log.info("artistList로");
		ArtistVO vo = aMapper.read(artistId);
		ServiceDTO dto = new ServiceDTO();
		dto.setList(service.getListById(artistId));
		model.addAttribute("artist", vo);
		model.addAttribute("list" ,dto.getList());
	}
	
	@GetMapping("/serviceList")
	public void serviceList(String artistId, Model model) {
		log.info("serviceList로 이동");
		log.info("artistList로");
		ArtistVO vo = aMapper.read(artistId);
		ServiceDTO dto = new ServiceDTO();
		dto.setList(service.getListById(artistId));
		model.addAttribute("artist", vo);
		model.addAttribute("list" ,dto.getList());
	}
	
	@GetMapping("/serviceView")
	public void serviceView(int sno, Model model) {
		ServiceVO sVO = service.getBySno(sno);
		List<ServiceImageVO> iVO = iMapper.getList(sno);
		List<ServiceTagVO> tVO = tMapper.getList(sno);
		log.info("sVO : " + sVO);
		log.info("iVO : " + iVO);
		log.info("tVO : " + tVO);
		model.addAttribute("sVO", sVO);
		model.addAttribute("iVO", iVO);
		model.addAttribute("tVO", tVO);
	}
	
	@DeleteMapping(value="/{sno}")
	public ResponseEntity<String> remove(@PathVariable("sno")int sno){
		service.delete(sno);
		iMapper.delete(sno);
		tMapper.delete(sno);
		return new ResponseEntity<>("success", HttpStatus.OK);
	}
	
	@GetMapping("/modify")
	public void toModify(int sno, Model model) {
		log.info("modify페이지로 이동");
		model.addAttribute("image", iMapper.getList(sno));
		model.addAttribute("service",service.getBySno(sno));
		model.addAttribute("tags", tMapper.getList(sno));
	}
	
	@GetMapping("/portfolio")
	public void portfolio(String artistId, Model model) {
		log.info("포트폴리오 페이지로");
		model.addAttribute("artist",aMapper.read(artistId));
	}
}
