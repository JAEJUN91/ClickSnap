package org.np.controller;



import org.np.domain.ReqCriteria; 
import org.np.domain.ReqReplyPageDTO;
import org.np.domain.ReqReplyVO;
import org.np.service.ReqReplyService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller
@Log4j
@RequestMapping("/reqReplies")
@AllArgsConstructor
public class ReqReplyController {
	private ReqReplyService service;
	
	//mediatype 값 정의 안 하면 기본 디폴트 값은 xml responseentity는 header와 body 값으로 날라간다
	//body에있는 replyvo 값을 vo로 정의해야 그 값을 쓸 수 있다
	@PreAuthorize("isAuthenticated()")
	@PostMapping(value="/new", consumes = "application/json", produces = {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> create(@RequestBody ReqReplyVO board /* 받은 정보를 replyvo에 담아 vo라고 말하겠다 */){
		log.info("reply VO!"+board);
		int insertCount = service.register(board);
		log.info("reply insert count : "+insertCount);
		return insertCount ==1 ? new ResponseEntity<>("success", HttpStatus.OK):new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@GetMapping(value = "/pages/{reqBno}/{page}", produces = { MediaType.APPLICATION_XML_VALUE,
            MediaType.APPLICATION_JSON_VALUE })
      public ResponseEntity<ReqReplyPageDTO> getList(@PathVariable("page") int page, @PathVariable("reqBno") Long reqBno) {
		
         log.info("getList......");
         ReqCriteria cri = new ReqCriteria(page, 10);
         log.info("getReplyListbno : " + reqBno);
         log.info("cri : " + cri);

         return new ResponseEntity<>(service.getListPage(cri, reqBno), HttpStatus.OK);
         
      }
	
	@GetMapping(value = "/{reqRno}", produces = {MediaType.APPLICATION_XML_VALUE, MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<ReqReplyVO> get(@PathVariable("reqRno")Long reqRno){
		log.info("get " + reqRno);
		return new ResponseEntity<>(service.get(reqRno), HttpStatus.OK);
	
	}
	
	@DeleteMapping(value = "/{reqRno}", produces = {MediaType.TEXT_PLAIN_VALUE})
	public ResponseEntity<String> remove(@PathVariable("reqRno")Long reqRno){
		log.info("remove.............."+reqRno);
		return service.remove(reqRno)==true? new ResponseEntity<>("success", HttpStatus.OK):
			new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
	
	@RequestMapping(method = { RequestMethod.POST}, value = "/{reqRno}/reply/{reply}", consumes = "application/json",
			produces = {MediaType.TEXT_PLAIN_VALUE})	
	public ResponseEntity<String> modify(@RequestBody ReqReplyVO board){
		log.info("modify......"+board);
		return service.modify(board)==true ? new ResponseEntity<>("success", HttpStatus.OK)
				:new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
