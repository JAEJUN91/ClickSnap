package org.np.controller;
import java.util.List;

import org.np.domain.NpCalendarDTO;
import org.np.service.NpCalendarService;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;



@Controller
@Log4j
@RequestMapping("/artPage/*")
@AllArgsConstructor
public class NpCalendarController {
	private NpCalendarService npService;
	
	@GetMapping("/calMain")
	public void calMain() {
		log.info("칼렌더 페이지로"); 
	}
	    
	/*@PostMapping(value ="/NpPurchaseListAction", produces=MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public ResponseEntity<List<NpReserveCalendarDTO>> getCalMainPost(@RequestParam("sno")int sno, Model model) {
        List<NpReserveCalendarDTO> calList = new ArrayList<NpReserveCalendarDTO>();
        log.info("CalendarController calMain()");
        
        model.addAttribute("list",purMapper.getPurchaseList(sno)); 
        model.addAttribute("cal", new NpCalendarUtil());
        
        return new ResponseEntity<>(calList, HttpStatus.OK );
    }*/
	

	
	  @GetMapping(value="/NpCalendarAction", produces =  MediaType.APPLICATION_JSON_VALUE, consumes= MediaType.APPLICATION_JSON_VALUE)
	  @ResponseBody public ResponseEntity<List<NpCalendarDTO>> getCalMainPost(){
		 System.out.println("1"); 
		 List<NpCalendarDTO> list = npService.getCalList(); 
		 log.info("npList" +list);
	  
	  	
		 return new ResponseEntity<>(list, HttpStatus.OK);
	  
	  }
	 
	
	

	
}
