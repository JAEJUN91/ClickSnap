package org.np.controller;

import java.io.IOException;

import javax.servlet.http.HttpSession;

import org.np.domain.Criteria;
import org.np.domain.ServiceDTO;
import org.np.mapper.ServiceImageMapper;
import org.np.mapper.ServiceMapper;
import org.np.mapper.ServiceTagMapper;
import org.np.service.ServiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.scribejava.core.model.OAuth2AccessToken;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Transactional
@Controller
@Log4j
public class MainController {

	/* NaverLoginBO */
    private NaverLoginBO naverLoginBO;
    private String apiResult = null;
    
    @Autowired
    private void setNaverLoginBO(NaverLoginBO naverLoginBO) {
        this.naverLoginBO = naverLoginBO;
    }
	
	@Setter(onMethod_= {@Autowired})
	private ServiceImageMapper iMapper;
	
	@Setter(onMethod_= {@Autowired})
	private ServiceMapper sMapper;
	
	@Setter(onMethod_= {@Autowired})
	private ServiceTagMapper tMapper;
	
	@Setter(onMethod_ = {@Autowired})
	private ServiceService service;
	
	@GetMapping("/artist/artistList")
	public void list(Model model) {
		log.info("artist List濡� �씠�룞");
	
		
		/*
		 * List<ServiceVO> sList = sMapper.searchList(); model.addAttribute("sList",sList);
		 */
	}
	
	@GetMapping(value="/service/search/type/{type}/keyword/{keyword}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<ServiceDTO> searchTK(Criteria cri){
		log.info("search 실행");
		return new ResponseEntity<>(service.searchList(cri), HttpStatus.OK);
	}
	
	@GetMapping(value="/service/search/location/{location}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<ServiceDTO> searchL(Criteria cri){
		log.info("search 실행");
		return new ResponseEntity<>(service.searchList(cri), HttpStatus.OK);
	}
	
	@GetMapping(value="/service/search/tagArr/{tagArr}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<ServiceDTO> searchTA(Criteria cri){
		log.info("search 실행");
		return new ResponseEntity<>(service.searchList(cri), HttpStatus.OK);
	}
	
	@GetMapping(value="/service/search/type/{type}/keyword/{keyword}/location/{location}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<ServiceDTO> searchTKL(Criteria cri){
		log.info("search 실행");
		return new ResponseEntity<>(service.searchList(cri), HttpStatus.OK);
	}
	
	@GetMapping(value="/service/search/type/{type}/keyword/{keyword}/tagArr/{tagArr}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<ServiceDTO> searchTKTA(Criteria cri){
		log.info("search 실행");
		return new ResponseEntity<>(service.searchList(cri), HttpStatus.OK);
	}
	
	@GetMapping(value="/service/search/location/{location}/tagArr/{tagArr}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<ServiceDTO> searchLTA(Criteria cri){
		log.info("search 실행");
		return new ResponseEntity<>(service.searchList(cri), HttpStatus.OK);
	}
	
	@GetMapping(value="/service/search/type/{type}/keyword/{keyword}/location/{location}/tagArr/{tagArr}", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<ServiceDTO> searchTKLTA(Criteria cri){
		log.info("search 실행");
		log.info(cri.getKeyword());
		log.info(cri.getType());
		return new ResponseEntity<>(service.searchList(cri), HttpStatus.OK);
	}
	
	
	 
//    //로그인 첫 화면 요청 메소드
//    @GetMapping(value = "/naverURL")
//    public String nav(Model model, HttpSession session) {
//        
//        /* 네이버아이디로 인증 URL을 생성하기 위하여 naverLoginBO클래스의 getAuthorizationUrl메소드 호출 */
//        String naverAuthUrl = naverLoginBO.getAuthorizationUrl(session);
//        
//        //https://nid.naver.com/oauth2.0/authorize?response_type=code&client_id=sE***************&
//        //redirect_uri=http%3A%2F%2F211.63.89.90%3A8090%2Flogin_project%2Fcallback&state=e68c269c-5ba9-4c31-85da-54c16c658125
//        System.out.println("네이버:" + naverAuthUrl);
//        
//        //네이버 
//        model.addAttribute("url", naverAuthUrl);
// 
//        /* 생성한 인증 URL을 View로 전달 */
//        return "include/nav";
//    }
 
    //네이버 로그인 성공시 callback호출 메소드
	@GetMapping(value = "/login")
    public String index(Model model, @RequestParam String code, @RequestParam String state, HttpSession session)
            throws IOException {
        System.out.println("여기는 callback");
        OAuth2AccessToken oauthToken;
        oauthToken = naverLoginBO.getAccessToken(session, code, state);
        //로그인 사용자 정보를 읽어온다.
        apiResult = naverLoginBO.getUserProfile(oauthToken);
        model.addAttribute("result", apiResult);
 
        /* 네이버 로그인 성공 페이지 View 호출 */
        return "/";
    }
}


