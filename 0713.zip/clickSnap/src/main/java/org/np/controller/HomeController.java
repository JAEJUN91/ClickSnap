package org.np.controller;

import java.io.IOException;
import java.security.Principal;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.np.mapper.ArtistMapper;
import org.np.mapper.MemberMapper;
import org.np.mapper.NpCalendarMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.scribejava.core.model.OAuth2AccessToken;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

/**
 * Handles requests for the application home page.
 */
@Controller
@Log4j
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Setter(onMethod_ = {@Autowired})
	private ArtistMapper aMapper;
	
	@Setter(onMethod_ = {@Autowired})
	private MemberMapper mMapper;
	
	@Setter(onMethod_ = {@Autowired})
	private NpCalendarMapper calMapper;
	

	/* NaverLoginBO */
    private NaverLoginBO naverLoginBO;
    private String apiResult = null;
    
    @Autowired
    private void setNaverLoginBO(NaverLoginBO naverLoginBO) {
        this.naverLoginBO = naverLoginBO;
    }
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model, Principal prin, HttpServletRequest request) {
		
		logger.info("index로 이동합니다.");
		model.addAttribute("aCount", aMapper.getCount());
		model.addAttribute("artist", aMapper.getAll());
		model.addAttribute("mCount", mMapper.getCount());
		model.addAttribute("rCount", calMapper.getCount());
		HttpSession session = request.getSession();
		session.setAttribute("prin", prin);
		
		
		  String naverAuthUrl = naverLoginBO.getAuthorizationUrl(session);
	        
	        //https://nid.naver.com/oauth2.0/authorize?response_type=code&client_id=sE***************&
	        //redirect_uri=http%3A%2F%2F211.63.89.90%3A8090%2Flogin_project%2Fcallback&state=e68c269c-5ba9-4c31-85da-54c16c658125
	        System.out.println("네이버:" + naverAuthUrl);
	        
	        //네이버 
	        model.addAttribute("url", naverAuthUrl);
		
	        
	        
	        
		return "index";
	}
	
	
	
}
