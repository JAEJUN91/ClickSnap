package org.np.service;

import java.util.List;

import org.np.domain.Criteria;
import org.np.domain.ServiceDTO;
import org.np.domain.ServiceImageVO;
import org.np.domain.ServiceTagVO;
import org.np.domain.ServiceVO;
import org.np.mapper.ServiceImageMapper;
import org.np.mapper.ServiceMapper;
import org.np.mapper.ServiceTagMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service
@AllArgsConstructor
@Log4j
public class ServiceServiceImpl implements ServiceService {

	@Setter(onMethod_ = {@Autowired})
	private ServiceMapper mapper;
	
	@Setter(onMethod_ = {@Autowired})
	private ServiceImageMapper iMapper;
	
	@Setter(onMethod_ = {@Autowired})
	private ServiceTagMapper tMapper;
	
	@Override
	public void insert(ServiceVO vo) {
		log.info("ServiceServiceImpl �떎�뻾");
		mapper.insert(vo);
		ServiceTagVO tVO = new ServiceTagVO();

		for(ServiceImageVO i : vo.getIList()) {
			ServiceImageVO iVO = new ServiceImageVO();
			iVO.setFileName(i.getFileName());
			iVO.setUploadPath(i.getUploadPath());
			iVO.setUuid(i.getUuid());
			iVO.setSno(vo.getSno());
			iMapper.insert(iVO);
		}
		
		for(String t:vo.getTList()) {
			tVO.setSno(vo.getSno());
			tVO.setTag(t);
			tMapper.insert(tVO);
		}
		//ServiceMapper, SeriviceImageMapper �몮�떎 �솢�슜
	}
	
	@Override
	public ServiceDTO searchByCategory(String categoty) {
		ServiceDTO sDTO = new ServiceDTO();
		sDTO.setList(mapper.searchByCategory(categoty));
		return sDTO;
	}
	
	@Override
	public List<ServiceVO> getListById(String artistId) {
		List<ServiceVO> list = mapper.getListById(artistId);
		return list;
	}
	
	@Override
	public ServiceVO getBySno(int sno) {
		ServiceVO vo = mapper.getBySno(sno);
		return vo;
	}
	
	@Override
	public void delete(int sno) {
		mapper.delete(sno);
	}
	
	@Override
	public List<ServiceVO> getList(){
		log.info("getList:");
		return mapper.getList();
	}
	
	@Override
	public List<ServiceVO> getList(Criteria cri){
		return mapper.getListWithPaging(cri);
	}
	
	@Override
	public List<ServiceVO> getRecList(){
		log.info("getRecList");
		return mapper.getRecList();
	}

	//키워드 찾기
	@Transactional
	@Override
	public ServiceDTO findByKeyword1(Criteria cri) {
		log.info("S(type/keyword): "+cri.getKeyword());
		return new ServiceDTO(mapper.search(cri));
	}
	
	@Transactional
	@Override
	public ServiceDTO findByKeyword2(Criteria cri) {
		log.info("S(tag): "+cri.getTagArr());
		return new ServiceDTO(mapper.search(cri));
	}
	
	@Transactional
	@Override
	public ServiceDTO findByKeyword3(Criteria cri) {
		log.info("S(location): "+cri.getLocation());
		return new ServiceDTO(mapper.search(cri));
	}
	
	@Transactional
	@Override
	public ServiceDTO findByKeyword4(Criteria cri) {
		log.info("S(location/tag): "+cri.getLocation()+cri.getTagArr());
		return new ServiceDTO(mapper.search(cri));
	}
	
	@Transactional
	@Override
	public ServiceDTO findByKeyword5(Criteria cri) {
		log.info("S(type/keyword/tag): "+cri.getType()+cri.getKeyword()+cri.getTagArr());
		return new ServiceDTO(mapper.search(cri));
	}
	
	@Transactional
	@Override
	public ServiceDTO findByKeyword6(Criteria cri) {
		log.info("S(type/keyword/location): "+cri.getType()+cri.getKeyword()+cri.getLocation());
		return new ServiceDTO(mapper.search(cri));
	}
	
	@Override
	@Transactional
	public ServiceDTO findByKeyword7(Criteria cri) {
		log.info("S(type/keyword/location/tag): "+cri.getType()+cri.getKeyword()+cri.getLocation()+cri.getTagArr());
		return new ServiceDTO(mapper.search(cri));
	}

	@Override
	public ServiceDTO searchList(Criteria cri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getTotal(Criteria cri) {
		// TODO Auto-generated method stub
		return mapper.getTotalCount(cri);
	}
}
