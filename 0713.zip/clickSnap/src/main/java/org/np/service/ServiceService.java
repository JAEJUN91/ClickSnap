package org.np.service;

import java.util.List;

import org.np.domain.Criteria;
import org.np.domain.ServiceDTO;
import org.np.domain.ServiceVO;
import org.springframework.web.bind.annotation.RequestParam;

public interface ServiceService {

	public void insert(ServiceVO vo);
	public ServiceDTO searchList(Criteria cri);
	public ServiceDTO searchByCategory(String category);
	public List<ServiceVO> getListById(String artistId);
	public ServiceVO getBySno(int sno);
	public void delete(int sno);
	
	public List<ServiceVO> getList();
	public List<ServiceVO> getList(Criteria cri);
	public List<ServiceVO> getRecList();
	public ServiceDTO findByKeyword1(@RequestParam("cri") Criteria cri);
	public ServiceDTO findByKeyword2(@RequestParam("cri") Criteria cri);
	public ServiceDTO findByKeyword3(@RequestParam("cri") Criteria cri);
	public ServiceDTO findByKeyword4(@RequestParam("cri") Criteria cri);
	public ServiceDTO findByKeyword5(@RequestParam("cri") Criteria cri);
	public ServiceDTO findByKeyword6(@RequestParam("cri") Criteria cri);
	public ServiceDTO findByKeyword7(@RequestParam("cri") Criteria cri);
	public int getTotal(Criteria cri);
}
