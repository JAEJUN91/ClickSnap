package org.np.service;

import java.util.List;

import org.np.domain.ReqBoardAttachVO;
import org.np.domain.ReqBoardVO;
import org.np.domain.ReqCriteria;

public interface ReqBoardService {
	public void register(ReqBoardVO board);
	public ReqBoardVO get(Long reqBno);

	public boolean modify(ReqBoardVO board); 
	public boolean remove(Long reqBno);
	public List<ReqBoardVO> getList();
	public List<ReqBoardVO> getList(ReqCriteria cri);
	public int getTotal(ReqCriteria cri);
	public List<ReqBoardAttachVO> getAttachList(Long reqBno);

	
}
