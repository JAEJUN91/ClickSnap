package org.np.service;

// �뒪耳�伊� 愿�由� �꽌鍮꾩뒪 �엫�뵆 :  �씠�옱以�
import java.util.List;

import org.np.domain.NpCalendarDTO;
import org.np.mapper.NpCalendarMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;


@Log4j
@Service
@AllArgsConstructor
public class NpCalendarServiceImpl implements NpCalendarService {
	@Setter(onMethod_ = {@Autowired})
	private NpCalendarMapper calMapper;
	
	
	@Override
	public List<NpCalendarDTO> getCalList() {
		log.info("get Calendar List " );
		return calMapper.getCalList();
	}

	@Override
	public NpCalendarDTO readCal(int resNo) {
		log.info("read Calendar by resNo");
		return calMapper.readCal(resNo);
	}
	
	@Override
	public int artistReservation(String artis_Id) {
		log.info("get Count of Reservations by artist");
		return calMapper.artistReservation(artis_Id);
	}
	
	@Override
	public NpCalendarDTO confirmReservation(String artist_Id, String cust_Id) {
		log.info("confirm Reservation");
		return calMapper.confirmReservation(artist_Id, cust_Id);
	}
	
	@Override
	public int custReservation(String cust_Id) {
		log.info("get Count of Reservations by customer");
		return calMapper.custReservation(cust_Id);
	}
	
	@Override
	public void insert(NpCalendarDTO dto) {
		log.info("insert reservation info");
		calMapper.insert(dto);
	}
	
	@Override
	public int getCount() {
		log.info("get all Reservation Count");
		return calMapper.getCount();
	}

}
