package org.np.service;


import java.util.List;

import org.np.domain.ReqCriteria;
import org.np.domain.ReqReplyPageDTO;
import org.np.domain.ReqReplyVO;
import org.np.mapper.ReqBoardMapper;
import org.np.mapper.ReqReplyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class ReqReplyServiceImpl implements ReqReplyService{
	@Setter(onMethod_ = @Autowired)
	private ReqReplyMapper mapper;
	
	@Setter(onMethod_ = @Autowired)
	private ReqBoardMapper boardMapper;
	
	@Transactional
	@Override
	public int register(ReqReplyVO board) {
		log.info("register ~ "+board);
		/* boardMapper.updateReplyCnt(board.getReqBno(),1); */
		return mapper.insert(board);
	}

	@Override
	public ReqReplyVO get(Long reqRno) {
		// TODO Auto-generated method stub
		log.info("get!" + reqRno);
		return mapper.read(reqRno);
	}

	@Override
	public boolean modify(ReqReplyVO reply) {
		// TODO Auto-generated method stub
		log.info("modify..." + reply);
		return mapper.update(reply)==1;
	}
	
	@Transactional
	@Override
	public boolean remove(Long reqRno) {
		// TODO Auto-generated method stub
		log.info("delete>>>"+reqRno);
		/* ReqReplyVO vo = mapper.read(reqRno); */
		/* boardMapper.updateReplyCnt(vo.getReqBno(),-1); */
		return mapper.delete(reqRno)==1;
	}

	@Override
	public List<ReqReplyVO> getList(ReqCriteria cri, Long reqBno) {
		// TODO Auto-generated method stub
		log.info("get Reply List of a Board ....." + reqBno);
		return mapper.getListWithPaging(cri, reqBno);
	}
	

	@Override
	public ReqReplyPageDTO getListPage(ReqCriteria cri, Long reqBno) {
		log.info(reqBno+"의 댓글 count 갯수:"+mapper.getCountByBno(reqBno));
		return new ReqReplyPageDTO(
				mapper.getCountByBno(reqBno),
				mapper.getListWithPaging(cri, reqBno));
	}
	
	
	
	
}
