package org.np.service;

import java.util.List;

import org.np.domain.ReqCriteria;
import org.np.domain.ReqReplyPageDTO;
import org.np.domain.ReqReplyVO;

public interface ReqReplyService {
	public int register(ReqReplyVO board);
	public ReqReplyVO get(Long reqRno);
	public boolean modify(ReqReplyVO reply);
	public boolean remove(Long reqRno);
	public List<ReqReplyVO> getList(ReqCriteria cri, Long reqBno);
	public ReqReplyPageDTO getListPage(ReqCriteria cri, Long reqBno);
}
