package org.np.service;

// �뒪耳�伊닿�由� �꽌鍮꾩뒪 : �씠�옱以�
import java.util.List;

import org.np.domain.NpCalendarDTO;


public interface NpCalendarService {
	public List<NpCalendarDTO> getCalList();
	public NpCalendarDTO readCal(int resNo);
	public int artistReservation(String artis_Id);
	public int custReservation(String cust_Id);
	public NpCalendarDTO confirmReservation(String artist_Id, String cust_Id);
	public void insert(NpCalendarDTO dto);
	public int getCount();
}
