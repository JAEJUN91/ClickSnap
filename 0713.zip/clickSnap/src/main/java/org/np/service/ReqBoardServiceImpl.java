package org.np.service;

import java.util.List;

import org.np.domain.ReqBoardAttachVO;
import org.np.domain.ReqBoardVO;
import org.np.domain.ReqCriteria;
import org.np.mapper.ReqBoardAttachMapper;
import org.np.mapper.ReqBoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;



@Service
@Log4j
@AllArgsConstructor
public class ReqBoardServiceImpl implements ReqBoardService{
	@Setter(onMethod_=@Autowired)
	private ReqBoardMapper mapper;
	
	@Setter(onMethod_=@Autowired)
	private ReqBoardAttachMapper attachMapper;
	
	
	@Transactional
	@Override
	public void register(ReqBoardVO board) {
		
		System.out.print("register" + board);
		
		mapper.insertSelectKey(board); //미리 처리한 이유가 미리 bno를 담고 있어야하니까
		System.out.print("service1: "+board.getReqBno());
		if(board.getAttachList() == null || board.getAttachList().size() <= 0) {
			return;
		}
		log.info("service2: "+board.getAttachList()+board.getReqBno());
		board.getAttachList().forEach(attach ->{ //forEach<-반복 getattachlists<-boardattchvo 가졍ㅁ
			attach.setReqBno(board.getReqBno());//여기서도 실어서 보내줌(long 타입)
			attachMapper.insert(attach);
			
			System.out.print("service3: "+board.getAttachList()+board.getReqBno());
		});
	}


	@Override
	public ReqBoardVO get(Long ReqBno) {
		// TODO Auto-generated method stub
		log.info("get : " + ReqBno);
		return mapper.read(ReqBno);
	}

	@Override
	public boolean modify(ReqBoardVO board) {
		// TODO Auto-generated method stub
		log.info("modify : " + board);
		attachMapper.deleteAll(board.getReqBno());//db에서 모든 정보 삿ㄱㅈ
		boolean modifyResult = mapper.update(board)==1;//board 테이블 정보 수정
		if(modifyResult&&board.getAttachList()!=null&&board.getAttachList().size()>0){
			board.getAttachList().forEach(attach->{
				attach.setReqBno(board.getReqBno());
				attachMapper.insert(attach);//db에 첨부파일 정보 저장
			});
		}
		return mapper.update(board)==1;
	}
	
	@Transactional
	@Override
	public boolean remove(Long reqBno) {
		// TODO Auto-generated method stub
		//System.out.println("나는 delete를할것이다.");
		log.info("delete : " + reqBno);
		attachMapper.deleteAll(reqBno);
		return mapper.delete(reqBno)==1;
	}

	@Override
	public List<ReqBoardVO> getList() {
		// TODO Auto-generated method stub
		log.info("getList : ");
		return mapper.getList();
	}
	
	@Override
	public List<ReqBoardVO> getList(ReqCriteria cri) {
		// TODO Auto-generated method stub
		log.info("getList criteria: " + cri);
		return mapper.getListWithPaging(cri);
	}
	
	@Override
	public int getTotal(ReqCriteria cri) {
		log.info("get total count");
		System.out.println("total_count");
		return mapper.getTotalCount(cri);
	}

	@Override
	public List<ReqBoardAttachVO> getAttachList(Long reqBno){
		log.info("get Attach list by bno" + reqBno);
		return attachMapper.findByBno(reqBno);
	}
	
	 
	
	
}
