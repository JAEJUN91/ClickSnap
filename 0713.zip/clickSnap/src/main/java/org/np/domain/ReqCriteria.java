package org.np.domain;

import lombok.Data;

/*유선영 - 전체 검색 로직 구현*/

@Data
public class ReqCriteria {
	private int pageNum;
	private int amount;
	private String type; 
	private String keyword;
	private String location;
	
	 
	public ReqCriteria() {
		this(1,10);
	}
	
	public ReqCriteria(int pageNum, int amount) {
		this.pageNum =pageNum;
		this.amount = amount;
	}

	public String[] getTypeArr() {//private String [] typeArr()이 잇있는 것과 같다
		return type == null? new String[] {} : type.split("");
	}
	 
}