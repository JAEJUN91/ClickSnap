package org.np.domain;

import java.util.List;

import lombok.Data;

@Data
public class ServiceDTO {
	
	public ServiceDTO(){};
	
	public ServiceDTO(List<ServiceVO> list) {
		this.list = list;
	}
	
	private List<ServiceVO> list;
} 
