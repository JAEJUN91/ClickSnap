package org.np.domain;

import lombok.Data;

@Data
public class NpCalendarDTO {
	
	private int resNo;
	private String resTitle;
	private String resDate;
	private String resTime;
	private int resPrice;
	private String resLocation;
	private String penalty; 
	private String cust_Id;
	private String custPhone;
	private String artist_Id;
	private String artistPhone;
	private String addPrice;
}
