package org.np.domain;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class ReqBoardVO {
	private String status;
	private Long reqBno;
	private String title;
	private String content;
	private String writer;
	private int price;
	private String category;
	private String location;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private Date hopeDate;
	private Date regDate;
	private String image;
	
	private int replyCnt; //답글 수
	
	private List<ReqBoardAttachVO> attachList;
	
}
