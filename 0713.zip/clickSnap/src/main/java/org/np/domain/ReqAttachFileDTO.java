package org.np.domain;

import lombok.Data;

@Data
public class ReqAttachFileDTO {
	private String fileName;
	private String uploadPath;
	private String uuid;
	private boolean image;
}
